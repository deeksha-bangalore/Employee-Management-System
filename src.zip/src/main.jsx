import React from "react";
import ReactDOM from "react-dom/client";
import "./global.css";
import { RouterProvider } from "react-router-dom";
import myRoutes from "./routes/Routes";
import AuthContextApi from "./context/AuthContextApi";

ReactDOM.createRoot(document.getElementById("root")).render(
  <>
    <AuthContextApi>
      <RouterProvider router={myRoutes} />
    </AuthContextApi>
  </>
);
