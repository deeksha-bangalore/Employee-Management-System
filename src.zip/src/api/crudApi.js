import axios from "axios";

//! C - Create the new users or add the users
//! post()
export let createUsers = (data) => {
  return axios.post("http://localhost:3001/users", data);
};

//! R - Access the users
//! get() -> It is used to access all the users.
export let getUsers = () => {
  return axios.get("http://localhost:3001/users");
};

//! U - Update the user
//! put()
export let updateUser = (id, data) => {
  return axios.put(`http://localhost:3001/users/${id}`, data);
};

//! D - Delete the user
//! delete()
export let deleteUser = (id) => {
  return axios.delete(`http://localhost:3001/users/${id}`);
};
