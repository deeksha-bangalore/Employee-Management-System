//! Routes configuration file

import { createBrowserRouter } from "react-router-dom";
import Layout from "../components/Layout";
import Home from "../pages/Home";
import Login from "../auth/Login";
import Register from "../auth/Register";
import AddUser from "../pages/AddUser";
import EditUserDetails from "../pages/EditUserDetails";
import ViewUserDetails from "../pages/ViewUserDetails";
import ForgotPassword from "../auth/ForgotPassword";
import Profile from "../pages/Profile";
import ProtectedRoutes from "../context/ProtectedRoutes";
import PublicRoutes from "../context/PublicRoutes";

let myRoutes = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: "/auth/login",
        element: (
          <PublicRoutes>
            <Login />
          </PublicRoutes>
        ),
      },
      {
        path: "/auth/register",
        element: (
          <PublicRoutes>
            <Register />
          </PublicRoutes>
        ),
      },
      {
        path: "/add-user",
        element: (
          <ProtectedRoutes>
            <AddUser />
          </ProtectedRoutes>
        ),
      },
      {
        path: "/edit-user",
        element: (
          <ProtectedRoutes>
            <EditUserDetails />
          </ProtectedRoutes>
        ),
      },
      {
        path: "/view-user",
        element: (
          <ProtectedRoutes>
            <ViewUserDetails />
          </ProtectedRoutes>
        ),
      },
      {
        path: "/profile",
        element: (
          <ProtectedRoutes>
            <Profile />
          </ProtectedRoutes>
        ),
      },
      {
        path: "/auth/forgot-password",
        element: (
          <PublicRoutes>
            <ForgotPassword />
          </PublicRoutes>
        ),
      },
      {
        path: "*",
        element: <h1>404! Page Not Found</h1>,
      },
    ],
  },
]);

export default myRoutes;
